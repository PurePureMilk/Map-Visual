str1 = "TCCACTGTTTGCGACTAGGT"
str2 = "TCCACTGTTTACGACTAGGT"
str3 = "TCCACTGTTCACGACTAGGT"
str4 = "TCCACTATTTACGATTAGGT"
str5 = "TCCACTGTTTACGATTAGGT"
str6 = "TCCATCGTCTGCAATCAGAT"

family = []

'''
set = {str1, str2, str3, str4, str5, str6};
array.add(str1)...array.add(str2)

a = 0;
b = 0; 
for (a < str.length)
  for(b < str.length)
    print(a comp b)
    print(compareStrand(set[a], set[b]))
    b++;
  a++;
  b = 0;

def compareStrand(dna1, dna2):
  count = 0
  for (i = 0; i < str.length; i++)
    if(dna1[i] == dna2[i])
      count++;
'''